# Copyright (c) 2024 - Richie. All rights reserved.


# Permissions

- Modification
- Distribution
- Private use


# Limitations

- Commercial use
- Liability
- Warranty
