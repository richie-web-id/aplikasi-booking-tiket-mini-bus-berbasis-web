$( function() {
    $( "#tutorial_name" ).autocomplete({
    source: 'script.php'  
    });
});