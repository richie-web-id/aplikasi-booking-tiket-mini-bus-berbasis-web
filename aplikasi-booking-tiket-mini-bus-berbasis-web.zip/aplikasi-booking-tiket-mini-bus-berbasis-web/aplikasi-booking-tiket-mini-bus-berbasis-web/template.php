<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
<div class="container"> 
               <div class="row">
                  <div class="col"><img src="img/icons8-1-96.png"></div> 
                  <div class="col"></div> 
                  <div class="col"><img src="img/icons8-steering-wheel-96.png"></div> 
               </div>
               <div class="row">
                  <div class="col"></div> 
                  <div class="col"><img src="img/icons8-2-96.png"></div> 
                  <div class="col"><img src="img/icons8-3-96.png"></div> 
               </div>
               <div class="row">
                  <div class="col"><img src="img/icons8-4-96.png"></div> 
                  <div class="col"></div> 
                  <div class="col"><img src="img/icons8-5-96.png"></div> 
               </div>
               <div class="row">
                  <div class="col"><img src="img/icons8-6-96.png"></div> 
                  <div class="col"><img src="img/icons8-7-96.png"></div> 
                  <div class="col"><img src="img/icons8-8-96.png"></div> 
               </div>
</div>